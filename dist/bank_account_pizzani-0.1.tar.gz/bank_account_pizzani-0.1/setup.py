from setuptools import setup

setup(name="bank_account_pizzani",
	version = "0.1",
	description = "Bank Account",
	packages = ["bank_account_pizzani"],
	author = "Bruno Pizzani Mendoza",
	zip_safe=False)